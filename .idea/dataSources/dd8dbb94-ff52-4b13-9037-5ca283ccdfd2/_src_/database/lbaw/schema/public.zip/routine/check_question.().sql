create function check_question() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF (SELECT COUNT(*) FROM answers, comments WHERE NEW.publicationid = answers.publicationid
                                                     OR NEW.publicationid = comments.publicationid) > 0 THEN
        RAISE EXCEPTION 'A question cant be an answer or a comment!';
    END IF;
    RETURN NULL;
END;
$$;
