CREATE TRIGGER auto_ban_on_warning_limit
AFTER INSERT ON warnings
FOR EACH ROW EXECUTE PROCEDURE trigger_auto_ban_on_warning_limit()