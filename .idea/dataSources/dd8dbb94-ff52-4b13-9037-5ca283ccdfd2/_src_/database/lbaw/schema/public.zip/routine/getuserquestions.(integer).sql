create function getuserquestions(userid integer) returns SETOF integer
LANGUAGE SQL
AS $$
select questions.publicationid
from publications
  inner join questions on publications.publicationid = questions.publicationid
  inner join users on publications.userid = users.userid
where users.userid = $1;
$$;
