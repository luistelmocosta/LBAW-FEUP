CREATE FUNCTION update_user_profile (uid integer, full_name character varying, e_mail character varying, location character varying, about_user text) RETURNS void
	LANGUAGE plpgsql
AS $$
begin
  UPDATE users
  SET fullname = full_name, email = e_mail, about = about_user
  WHERE users.userid = uid;
end 
$$
