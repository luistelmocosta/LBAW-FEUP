create function question_total_answers(question_id integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE answers_count INTEGER;
BEGIN
  SELECT COUNT(*) FROM answers WHERE answers.questionid = question_id
  INTO answers_count;

  IF answers_count is null THEN
    answers_count := 0;
  END IF;

  return answers_count;
END
$$;
