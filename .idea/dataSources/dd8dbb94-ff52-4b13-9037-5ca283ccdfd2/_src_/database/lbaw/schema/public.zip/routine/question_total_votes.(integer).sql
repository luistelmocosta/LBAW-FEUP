create function question_total_votes(question_id integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE questions_count INTEGER;
BEGIN
  SELECT SUM(votes.values) FROM votes WHERE votes.publicationid = question_id
  INTO questions_count;

  IF questions_count is null THEN
    questions_count := 0;
  END IF;

  return questions_count;
END
$$;
