create function check_publication() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF (SELECT COUNT(*) FROM answers WHERE NEW.publicationid = answers.publicationid) > 0 THEN
    RAISE EXCEPTION 'A question cant be an answer!';
  END IF;
  RETURN NULL;
END;
$$;
