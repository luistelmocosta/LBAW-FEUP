create function top_scored_users() returns TABLE(username character varying, count_votes_rating_received integer, count_questions integer, count_answers integer, count_comments integer)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT users.username,
    count_vote_rating_received_user(users.userid) as total_votes,
    user_total_questions(users.userid) as total_questions,
    user_total_answers(users.userid) as total_answers,
    user_total_comments(users.userid) as total_comments
  FROM votes
    INNER JOIN publications
      ON votes.publicationid = publications.publicationid
    INNER JOIN users
      ON publications.userid = users.userid
  GROUP BY users.userid
  ORDER BY total_votes
  DESC LIMIT 5;
END
$$;
