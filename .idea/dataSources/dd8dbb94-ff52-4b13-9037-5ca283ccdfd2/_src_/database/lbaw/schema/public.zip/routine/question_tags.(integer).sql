create function question_tags(pquestion_id integer) returns TABLE(tag character varying)
LANGUAGE plpgsql
AS $$
BEGIN
    return QUERY
    SELECT tags.name
    FROM tags INNER JOIN questiontags ON tags.tagid = questiontags.tagid
    WHERE questiontags.questionid = pquestion_id;
END
$$;
