create function search_questions(psearch text) returns TABLE(questionid integer)
LANGUAGE plpgsql
AS $$
BEGIN
    return QUERY
    SELECT DISTINCT (questions.publicationid)
    FROM questions
    WHERE to_tsvector(coalesce(questions.title, '')) @@ plainto_tsquery(psearch)
          OR
          publicationid IN (
              SELECT DISTINCT(publications.publicationid) FROM publications WHERE to_tsvector(coalesce(publications.body, '')) @@ plainto_tsquery(psearch)
          )
    ;
END
$$;
