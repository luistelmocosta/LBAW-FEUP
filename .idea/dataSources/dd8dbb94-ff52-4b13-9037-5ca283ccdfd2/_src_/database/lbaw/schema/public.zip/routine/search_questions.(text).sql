create function search_questions(psearch text) returns TABLE(questionid integer)
LANGUAGE plpgsql
AS $$
BEGIN
  return QUERY
  SELECT DISTINCT publications.publicationid
  FROM questions, publications
  WHERE to_tsvector(coalesce(questions.title,'') || ' ' || coalesce(publications.body,'')) @@ to_tsquery(psearch)
        OR questionid IN (
    SELECT DISTINCT(answers.questionid) FROM answers INNER JOIN publications ON answers.publicationid = publications.publicationid
    WHERE to_tsvector(coalesce(publications.body)) @@ to_tsquery(psearch)
  )
  ;
END
$$;
