create function getusernamefromquestion(questionid integer) returns character varying
LANGUAGE SQL
AS $$
select users.username
from publications
  inner join questions on publications.publicationid = questions.publicationid
  inner join users on publications.userid = users.userid
where questions.publicationid = $1;
SELECT * FROM getusernamefromquestion(questionid := $1);
$$;
