CREATE FUNCTION getusernamefromquestion (questionid integer) RETURNS character varying
	LANGUAGE plpgsql
AS $$
BEGIN
  SELECT users.username
  FROM publications
    INNER JOIN questions on publications.publicationid = questions.publicationid
    INNER JOIN users on publications.userid = users.userid
  where questions.publicationid = $1;
END;

$$
