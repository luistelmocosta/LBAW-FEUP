create function trigger_auto_ban_on_warning_limit() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF (SELECT COUNT(*)
        FROM modregisters INNER JOIN users ON modregisters.userid_author = users.userid
            INNER JOIN warnings ON modregisters.modregisterid = warnings.warningid
        GROUP BY userid_target) = 3 THEN
        INSERT INTO bans(banid) VALUES(NEW.warningid);
    END IF;
    RETURN NULL;
END;
$$;
