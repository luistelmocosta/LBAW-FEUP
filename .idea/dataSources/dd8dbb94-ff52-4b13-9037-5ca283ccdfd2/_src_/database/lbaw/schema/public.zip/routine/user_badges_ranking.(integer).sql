create function user_badges_ranking(puser_id integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE points INTEGER;
    BEGIN
        IF count_vote_rating_received_user(puser_id) < 5 THEN
            INSERT INTO userbadges(userid, badgeid) VALUES (puser_id, 1);
        END IF;
        IF count_vote_rating_received_user(puser_id) >= 5 THEN
            INSERT INTO userbadges(userid, badgeid) VALUES (puser_id, 2);
        END IF;
        IF count_vote_rating_received_user(puser_id) > 10 THEN
            INSERT INTO userbadges(userid, badgeid) VALUES (puser_id, 3);
        END IF;
        IF count_vote_rating_received_user(puser_id) > 50 THEN
            INSERT INTO userbadges(userid, badgeid) VALUES (puser_id, 4);
        END IF;
        IF count_vote_rating_received_user(puser_id) > 100 THEN
            INSERT INTO userbadges(userid, badgeid) VALUES (puser_id, 5);
        END IF;
    END

$$;
