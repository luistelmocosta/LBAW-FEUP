create function question_answers(pquestion_id integer) returns TABLE(id integer, user_id integer, username character varying, body text, created_at timestamp without time zone)
LANGUAGE plpgsql
AS $$
BEGIN
      RETURN QUERY
      SELECT answers.publicationid, users.userid, users.username, publications.body, publications.creation_date
      FROM answers INNER JOIN publications ON answers.publicationid = publications.publicationid
          RIGHT JOIN users ON publications.userid = users.userid
      WHERE answers.questionid = pquestion_id;
  END

$$;
