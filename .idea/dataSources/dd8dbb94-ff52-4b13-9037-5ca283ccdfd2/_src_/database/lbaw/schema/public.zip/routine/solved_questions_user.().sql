create function solved_questions_user() returns TABLE(userid integer)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT COUNT(*) FROM questions INNER JOIN publications ON questions.publicationid = publications.publicationid
  WHERE solved_date IS NOT NULL AND publications.userid=4;
END;
$$;
