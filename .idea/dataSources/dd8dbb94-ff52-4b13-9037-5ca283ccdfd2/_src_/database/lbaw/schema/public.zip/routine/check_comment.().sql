create function check_comment() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF (SELECT COUNT(*) FROM answers, questions WHERE NEW.publicationid = questions.publicationid
                                                    OR NEW.publicationid = answers.publicationid) > 0 THEN
    RAISE EXCEPTION 'A comment cant be a question or an answer!';
  END IF;
  RETURN NULL;
END;
$$;
