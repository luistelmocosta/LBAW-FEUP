create function user_total_comments(puser_id integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE questions_count INTEGER;
BEGIN
    SELECT COUNT(*) FROM comments
        INNER JOIN publications
            ON comments.publicationid = publications.publicationid
    WHERE publications.userid = puser_id
    INTO questions_count;

    IF questions_count is null THEN
        questions_count := 0;
    END IF;

    return questions_count;
END
$$;
