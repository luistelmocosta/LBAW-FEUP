create function get_related_questions(qid integer) returns TABLE(publicationid integer, title character varying, count_answers integer, creation_date timestamp without time zone, count_votes_rating_received integer)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT questions.publicationid,
    questions.title,
    question_total_answers(qid) AS answers_count,
    publications.creation_date,
    question_total_votes(qid) AS total_votes
  FROM questions
    INNER JOIN publications
      ON questions.publicationid = publications.publicationid
  WHERE questions.categoryid = 14
  ORDER BY total_votes
  DESC LIMIT 5;
END
$$;
