CREATE TRIGGER answer_update_question_timestamp
BEFORE INSERT OR UPDATE ON publications
FOR EACH ROW EXECUTE PROCEDURE trigger_update_question_timestamp()