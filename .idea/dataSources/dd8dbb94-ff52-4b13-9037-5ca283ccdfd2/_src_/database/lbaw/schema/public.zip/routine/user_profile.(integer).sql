create function user_profile(puser_id integer) returns TABLE(fullname character varying, username character varying, email character varying, about character varying, location character varying, role character varying, created_at date, count_votes_rating_received integer, count_questions bigint, count_answers bigint, count_votes_made bigint)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT users.fullname, users.username, users.email, users.about,
    (SELECT locations.name FROM locations WHERE users.locationid = locations.locationid),
    (SELECT name FROM users INNER JOIN userroles ON users.roleid = userroles.roleid WHERE userid = puser_id),
    users.signup_date,
    count_vote_rating_received_user(puser_id),
    (SELECT COUNT(*) FROM publications INNER JOIN questions ON questions.publicationid = publications.publicationid
      RIGHT JOIN users ON publications.userid = users.userid WHERE users.userid = puser_id),
    (SELECT COUNT(*) FROM publications INNER JOIN answers ON answers.publicationid = publications.publicationid
      RIGHT JOIN users ON publications.userid = users.userid WHERE users.userid = puser_id),
    (SELECT COUNT(*) FROM votes WHERE votes.userid = puser_id)
  FROM users
  WHERE users.userid = puser_id;
END
$$;
