CREATE FUNCTION trigger_update_question_timestamp () RETURNS trigger
	LANGUAGE plpgsql
AS $$
BEGIN
  new.last_edit_date := now();
  RETURN NEW;
END;
$$
