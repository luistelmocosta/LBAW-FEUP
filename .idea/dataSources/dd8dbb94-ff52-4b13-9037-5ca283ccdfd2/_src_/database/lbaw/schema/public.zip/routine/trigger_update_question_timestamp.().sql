create function trigger_update_question_timestamp() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    new.last_edit_date := now();
    RETURN NEW;
END;
$$;
