create function check_question_is_solved() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
IF (OLD.solved_date IS NOT NULL) THEN
RAISE EXCEPTION 'Question already solved!';
END IF;
END;
$$;
