create function user_badges_ranking() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE points INTEGER;
BEGIN
  IF count_vote_rating_received_user(NEW.userid) < 5 THEN
    INSERT INTO userbadges(userid, badgeid) VALUES (NEW.userid, 1);
  END IF;
  IF count_vote_rating_received_user(NEW.userid) >= 5 THEN
    INSERT INTO userbadges(userid, badgeid) VALUES (NEW.userid, 2);
  END IF;
  IF count_vote_rating_received_user(NEW.userid) > 10 THEN
    INSERT INTO userbadges(userid, badgeid) VALUES (NEW.userid, 3);
  END IF;
  IF count_vote_rating_received_user(NEW.userid) > 50 THEN
    INSERT INTO userbadges(userid, badgeid) VALUES (NEW.userid, 4);
  END IF;
  IF count_vote_rating_received_user(NEW.userid) > 100 THEN
    INSERT INTO userbadges(userid, badgeid) VALUES (NEW.userid, 5);
  END IF;
END
$$;
