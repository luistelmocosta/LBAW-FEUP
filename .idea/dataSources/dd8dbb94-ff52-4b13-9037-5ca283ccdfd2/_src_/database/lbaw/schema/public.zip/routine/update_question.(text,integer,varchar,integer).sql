create function update_question(body_edited text, questionid integer, title_edited character varying, categoryid_edited integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE result INTEGER;
begin
  UPDATE publications
    SET body = body_edited
    WHERE publications.publicationid = questionid
  returning publications.publicationid AS publicationid INTO result;

  UPDATE questions
  SET title = title_edited, categoryid = categoryid_edited
  WHERE questions.publicationid = questionid;
end
$$;
