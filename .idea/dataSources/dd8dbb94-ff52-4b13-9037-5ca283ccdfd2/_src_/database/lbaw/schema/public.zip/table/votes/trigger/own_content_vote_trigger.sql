CREATE TRIGGER own_content_vote_trigger
AFTER INSERT OR UPDATE ON votes
FOR EACH ROW EXECUTE PROCEDURE own_content_vote()