create function check_answer() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF (SELECT COUNT(*) FROM comments, questions WHERE NEW.publicationid = questions.publicationid
                                                     OR NEW.publicationid = comments.publicationid) > 0 THEN
    RAISE EXCEPTION 'An answer cant be a question or a comment!';
  END IF;
  RETURN NULL;
END;
$$;
