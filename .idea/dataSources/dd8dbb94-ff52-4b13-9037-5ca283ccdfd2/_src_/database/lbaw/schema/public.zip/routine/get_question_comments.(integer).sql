CREATE FUNCTION get_question_comments (qid integer) RETURNS TABLE(publicationid integer, body text, creation_date timestamp without time zone, userid integer, username character varying)
	LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT publications.publicationid, publications.body, publications.creation_date, users.userid, users.username
  FROM questioncomments INNER JOIN publications ON questioncomments.commentid = publications.publicationid
    LEFT JOIN users ON publications.userid = users.userid
  WHERE questioncomments.questionid= qid;
END
$$
