create function question_details_from_id(pubid integer) returns TABLE(publicationid integer, title character varying, body text, creation_date timestamp without time zone, solved_date timestamp without time zone, username character varying, userid integer, answers_count bigint, upvotes bigint, down_votes bigint, views_counter bigint, category character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT questions.publicationid,  questions.title, publications.body,
    publications.creation_date, questions.solved_date, users.username,users.userid,
    (SELECT COUNT(*) FROM question_answers(questions.publicationid)) AS answers_count,
    (SELECT COUNT (*) FROM votes WHERE votes.publicationid = pubid AND votes.values = 1) AS upvotes,
    (SELECT COUNT (*) FROM votes WHERE votes.publicationid = pubid AND votes.values = -1) AS down_votes,
    questions.views_counter,
    categories.name
  FROM questions
    INNER JOIN publications
      ON questions.publicationid = publications.publicationid
    INNER JOIN categories ON questions.categoryid = categories.categoryid
    LEFT JOIN users ON publications.userid = users.userid
  WHERE questions.publicationid = pubid;
END
$$;
