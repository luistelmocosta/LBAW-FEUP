create function question_details_from_id(pubid integer) returns TABLE(publicationid integer, title character varying, body text, creation_date timestamp without time zone, solved_date timestamp without time zone, username character varying, userid integer, answers_count bigint, upvotes bigint)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT questions.publicationid,  questions.title, publications.body,
    publications.creation_date, questions.solved_date, users.username,users.userid,
    (SELECT COUNT(*) FROM question_answers(questions.publicationid)) AS answers_count,
    (SELECT COUNT (*) FROM votes WHERE questions.publicationid = pubid) AS upvotes
  FROM questions
    INNER JOIN publications
      ON questions.publicationid = publications.publicationid
    LEFT JOIN users ON publications.userid = users.userid
  WHERE questions.publicationid = pubid;
END
$$;
