CREATE FUNCTION insert_into_answercomments (userid integer, answerid integer, body text) RETURNS void
	LANGUAGE plpgsql
AS $$
DECLARE result INTEGER;
begin
  insert into publications(body, userid)
  VALUES (body, userid)
  returning publications.publicationid AS publicationid INTO result;

  insert into comments(publicationid) VALUES (result);

  insert into answercomments(commentid, answerid) VALUES (result, answerid);
end 
$$
