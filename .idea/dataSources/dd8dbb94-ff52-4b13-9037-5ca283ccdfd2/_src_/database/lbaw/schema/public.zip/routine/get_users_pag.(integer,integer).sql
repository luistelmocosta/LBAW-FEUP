create function get_users_pag(skip integer, limitnumber integer) returns TABLE(userid integer, role character varying, username character varying, email character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT users.userid,
  (SELECT name FROM userroles INNER JOIN users ON users.roleid = userroles.roleid WHERE userid = users.userid),
    users.username,
    users.email
  FROM users
  ORDER BY userid ASC
  LIMIT limitNumber
  OFFSET skip;
END
$$;
