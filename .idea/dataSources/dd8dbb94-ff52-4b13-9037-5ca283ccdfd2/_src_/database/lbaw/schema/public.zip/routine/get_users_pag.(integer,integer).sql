create function get_users_pag(skip integer, limitnumber integer) returns TABLE(userid integer, roleid integer, username character varying, email character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT users.userid,
    users.roleid,
    users.username,
    users.email
  FROM users
  ORDER BY userid ASC
  LIMIT limitNumber
  OFFSET skip;
END
$$;
