create function get_answer_comments(aid integer) returns TABLE(publicationid integer, body text, creation_date timestamp without time zone, userid integer, username character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT publications.publicationid, publications.body, publications.creation_date, users.userid, users.username
  FROM answercomments INNER JOIN publications ON answercomments.commentid = publications.publicationid
    LEFT JOIN users ON publications.userid = users.userid
  WHERE answercomments.answerid = aid;
END
$$;
