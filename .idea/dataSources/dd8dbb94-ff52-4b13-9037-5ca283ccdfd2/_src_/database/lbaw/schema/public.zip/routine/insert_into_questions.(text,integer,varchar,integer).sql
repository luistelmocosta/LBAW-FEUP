create function insert_into_questions(body text, userid integer, title character varying, categoryid integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE result INTEGER;
begin
    insert into publications(body, userid)
    VALUES (body, userid)
    returning publications.publicationid AS publicationid INTO result;

    insert into questions(publicationid ,title, categoryid) VALUES (result, title, categoryid);
end
$$;
