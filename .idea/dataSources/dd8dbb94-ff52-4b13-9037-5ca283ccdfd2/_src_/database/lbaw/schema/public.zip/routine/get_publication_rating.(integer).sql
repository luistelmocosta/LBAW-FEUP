create function get_publication_rating(pid integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE rating INTEGER;
BEGIN
  SELECT SUM(votes.values) AS rating FROM votes WHERE votes.publicationid = pid
  INTO rating;
  RETURN rating;
END
$$;
